import os
import scipy
from PIL import Image
from PIL import ImageFont
from PIL import ImageDraw
import numpy as np
import numpy.linalg as linalg
import copy

# reads a file of list of images and
# returns the image matrix of all the images
def read_images(datafile):
    basedir = 'data/'
    flist = os.listdir(basedir)
    faces = []

    for item in flist:

        image = Image.open("data/"+item.strip('\n'))
        image = np.array(image.getdata()).ravel()
        faces.append(copy.deepcopy(image))

    return faces

def scaledown(I):
    minI = min(I)
    maxI = max(I)

    N = I - minI
    N = N / (maxI - minI)
    return N

def normalize(I,l,h):
    minI = min(I)
    maxI = max(I)

    N = I - minI
    N = N / (maxI - minI)

    N = N * (h-1)
    N = N + 1
    return N

def magnitude(v):
    return np.sqrt(sum(v[i]*v[i] for i in range(len(v))))

def orthonormalize(v):
    vmag = magnitude(v)
    return [v[i]/vmag for i in range(len(v))]

def train():
    faces = read_images("data.txt")
    m = len(faces)
    average_face = sum(faces) / len(faces)
    diff_faces = faces - average_face
    diff_faces = diff_faces.transpose()

    # calculate eigenfaces
    L =  diff_faces.transpose().dot(diff_faces)
    eigenvalues, eigenvectors = linalg.eig(L)

    # sort eigenvectors corresponding to descending order
    # of eigenvalues
    idx = eigenvalues.argsort()[::-1]
    eigenvalues = eigenvalues[idx]
    eigenvectors = eigenvectors[:,idx]

    
    eigenvectors = diff_faces.dot( eigenvectors )
    
    # normalize the eigenvectors such that ||u|| = 1
    for i in range(m):
        mag = magnitude(eigenvectors[:,i])
        for j in range(len(eigenvectors[:,i])):
            eigenvectors[:,i][j] = eigenvectors[:,i][j]/mag

    # now we should prepare the feature vector w[i] for each image in training set
    w = np.zeros((m,m))
    for i in range(m):
        w[i] = [eigenvectors[:,j].transpose().dot(diff_faces[:,i]) for j in range(m)]

    rast = []
    for i in range(m):
        test_image = diff_faces[:,i]
        w_test = [eigenvectors[:,i].dot(test_image) for i in range(m)]
        distances = [linalg.norm(w_test - w[i]) for i in range(m)]
        rast.append(min([x for x in distances if x!=0]))

    threshold = 0.7*max(rast)

    return average_face,eigenvectors, w, threshold


if __name__=="__main__":
    average_face, eigenvectors , w, threshold = train()
      
    m = len(w)

    # testing part
    # tests on image at a time
    test_image = Image.open("test/1.tiff")
    test_image_array = np.array(test_image.getdata()).ravel()
    test_input = test_image_array - average_face



    w_input = [eigenvectors[:,i].dot(test_input) for i in range(m)]
    distances = [linalg.norm(w_input-w[i]) for i in range(m)]

    minIdx = np.argmin(distances)

    reconstructed = np.zeros((1,256*256))
    for i in range(m):
        reconstructed = reconstructed + w_input[i] * eigenvectors[:,i]

    
    closest_match = np.zeros((1,256*256))

    if min(distances)<threshold:
        for i in range(m):
            closest_match = closest_match + w[minIdx][i] * eigenvectors[:,i]
        closest_match = closest_match + average_face
    
   
    face1 = test_image_array.reshape(256,256).astype(dtype=np.uint8)
    face2 = reconstructed + average_face
    face2 = face2.reshape(256,256).astype(dtype=np.uint8)
    face3 = closest_match
    face3 = face3.reshape(256,256).astype(dtype=np.uint8)

    face = np.hstack((face1, face2,face3))

    Image.fromarray(face).show()
    
